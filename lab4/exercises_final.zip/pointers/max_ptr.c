/*@
  requires \valid(x) && \valid(y);
  requires \separated(x, y);
  assigns *x, *y;
  ensures *x == (\old(*x) >= \old(*y) ? \old(*x) : \old(*y));
  ensures *y == (\old(*x) >= \old(*y) ? \old(*y) : \old(*x));
*/
void max_ptr(int* x, int* y)
{
    if (*x < *y) {
        int t = *x;
        *x = *y;
        *y = t;
    }
}

int v = 5;
void main(void)
{
    int x = 10;
    int y = 7;
    max_ptr(&x, &y);
    //@ assert x == 10;
    //@ assert y == 7;
    //@ assert v == 5;

    x = 8;
    y = 15;
    max_ptr(&x, &y);
    //@ assert x == 15;
    //@ assert y == 8;
    //@ assert v == 5;
}