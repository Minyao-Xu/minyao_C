#include <limits.h>
/*@
  requires \valid(x);
  requires \valid_read(y);
  requires \separated(x, y);

  //signed overflow for: *x = *x - *y;
  requires (int)*x >= (int)INT_MIN + (int)*y;
  requires (int)*x <= (int)INT_MAX + (int)*y;

  assigns *x;
  ensures *x == \old(*x) - \old(*y);
*/
void decr_by(int* x, int const* y)
{
    *x = *x - *y;
}

void main(void)
{
    int x = 7;
    int y = 3;
    decr_by(&x, &y);
    //@ assert x == 4;
    //@ assert y == 3;
}