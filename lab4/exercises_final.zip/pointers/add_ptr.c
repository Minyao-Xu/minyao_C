#include <limits.h>

/*@
  requires \valid_read(a);
  requires \valid_read(b);

  // Prevent signed overflow in: *a + *b
  requires (int)*a >= (int)INT_MIN - (int)*b;
  requires (int)*a <= (int)INT_MAX - (int)*b;

  assigns \nothing;

  ensures \result == *a + *b;
*/
int add_ptr(int* a, int* b)
{
    return *a + *b;
}
void main(void)
{
    int a = 13;
    int b = 15;
    int r = add_ptr(&a, &b);
    //@ assert r == 28;
}