/*@
  requires 1 <= month <= 12;
  assigns \nothing;
  ensures \result \in {28, 30, 31};
*/
int number_of_days(int month){
  int days[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
  return days[month-1];
}