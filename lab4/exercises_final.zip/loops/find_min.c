/*@
  requires len > 0;
  requires \valid_read(arr + (0 .. len-1));
  // required by the exercise: there exists at least one element
  requires \exists integer i; 0 <= i < len;

  assigns \nothing;

  // result is an element of the array
  ensures \exists integer i; 0 <= i < len && \result == arr[i];
  // result is <= every array element (i.e., a minimum value)
  ensures \forall integer j; 0 <= j < len ==> \result <= arr[j];
*/
int find_min(int* arr, int len)
{
    int m = arr[0];

    /*@
      loop invariant 1 <= i <= len;
      loop invariant \exists integer k; 0 <= k < i && m == arr[k];
      loop invariant \forall integer k; 0 <= k < i ==> m <= arr[k];
      loop assigns i, m;
      loop variant len - i;
    */
    for (int i = 1; i < len; i++) {
        if (arr[i] < m) {
            m = arr[i];
        }
    }
    return m;
}

void main(void)
{
    int a[] = {3, 5, 18, 2, 12};
    int r = find_min(a, 5);
    //@ assert r == 2;
}