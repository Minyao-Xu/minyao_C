/*@
  requires len > 0;
  requires \valid_read(arr + (0 .. len-1));
  assigns \nothing;

  behavior sorted:
    assumes \forall integer i; 1 <= i < len ==> arr[i-1] <= arr[i];
    ensures \result == 1;

  behavior not_sorted:
    assumes \exists integer i; 1 <= i < len && arr[i-1] > arr[i];
    ensures \result == 0;

  complete behaviors;
  disjoint behaviors;
*/
int is_sorted(int* arr, int len) 
{
    /*@
      loop invariant 1 <= i <= len;
      loop invariant \forall integer j; 1 <= j < i ==> arr[j-1] <= arr[j];
      loop assigns i;
      loop variant len - i;
    */
    for(int i = 1; i < len; i++){
        if(arr[i-1] > arr[i]){
            return 0;
        }
    }
    return 1;
}

int main()
{
    int a1[] = {1,2,3};
    int a2[] = {2,1,3}; 

    int r1 = is_sorted(a1, 3); 
    int r2 = is_sorted(a2, 3); 

    //@ assert r1 == 1;
    //@ assert r2 == 0; 
}