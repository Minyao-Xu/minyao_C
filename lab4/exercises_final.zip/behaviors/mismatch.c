/*@
  requires n >= 0;
  requires \valid_read(a + (0 .. n-1));
  requires \valid_read(b + (0 .. n-1));
  assigns \nothing;

  ensures 0 <= \result <= n;
  ensures \forall integer j; 0 <= j < \result ==> a[j] == b[j];
  ensures \result < n ==> a[\result] != b[\result];
  ensures \result == n ==> \forall integer j; 0 <= j < n ==> a[j] == b[j];
*/
int mismatch(int* a, int* b, int n){
    /*@
      loop invariant 0 <= i <= n;
      loop invariant \forall integer j; 0 <= j < i ==> a[j] == b[j];
      loop assigns i;
      loop variant n - i;
    */
    for(int i=0;i<n;i++){
        if(a[i]!=b[i]){
            return i;
        }
    }
    return n;
}
void main(void){
    int a[]={1,2,3,4,5};
    int b[]={1,2,6,4,5};
    int c[]={1,2,3,4,5};
    int r1=mismatch(a,b,5);
    //@assert r1==2;

    int r2=mismatch(a,c,5);
    //@assert r2==5;

}
